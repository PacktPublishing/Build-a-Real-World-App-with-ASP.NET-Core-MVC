﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LittlePacktBookstore.Common
{
    public class ApiAuthenticationHelper
    {

        internal static readonly string Key = "DD62DAA7-4E9E-405D-BC9E-5A5508233843";
        internal static readonly string Issuer = "LittlePacktBookStore";
        internal static readonly string Audience = "App_User";
    }
}
