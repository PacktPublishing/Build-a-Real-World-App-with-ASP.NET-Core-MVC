using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LittlePacktBookstore.Models;
using LittlePacktBookstore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace LittlePacktBookstore.Controllers
{
    public class UserController : Controller
    {
        private readonly UserManager<SiteUser> _userManager;

        public UserController(UserManager<SiteUser> userManager)
        {
            _userManager = userManager;
        }

        // GET: User
        public ActionResult Index()
        {
            return View();
        }

        // GET: User/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: User/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: User/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: User/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [HttpGet]
        [Authorize(Roles ="User")]
        public IActionResult Profile()
        {
            var user = _userManager.Users.First(x => x.Email == User.Identity.Name);
            return View(new UserViewModel
            {
                Id = user.Id,
                Email = user.Email,
                FirstName=user.FirstName,
                LastName = user.LastName,
                Phone = user.PhoneNumber
            });
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Profile(UserViewModel model)
        {
            if(ModelState.IsValid)
            {
                var user = _userManager.Users.First(x => x.Email == User.Identity.Name);
                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.Email = model.Email;
                user.NormalizedEmail = model.Email.ToUpper();
                user.UserName = model.Email;
                user.NormalizedUserName = model.Email.ToUpper();
                user.PhoneNumber = model.Phone;

                var result = await _userManager.UpdateAsync(user);
                if(result.Succeeded)
                {
                    ViewData["message"] = "Successfully Updated Profile";
                }
                else
                {
                    ViewData["message"] = "Profile Update Error!";
                }
            }
            return View();
        }

        [HttpGet]
        [Authorize(Roles = "User")]
        public IActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            try
            {
                if(ModelState.IsValid == true)
                {
                    var user = await _userManager.FindByEmailAsync(User.Identity.Name);
                    var result = await _userManager.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);
                    if(result.Succeeded)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    ModelState.AddModelError("", "Password could not be changed.");
                    return View();
                }
                ModelState.AddModelError("", "Invalid data passed.");
                return View();
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Password could not be changed due to an error.");
                return View();
            }
        }

    }
}